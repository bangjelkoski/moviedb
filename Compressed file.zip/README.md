# MovieDB using Vue.js

> Simple Vue.js Project for Movie Informations