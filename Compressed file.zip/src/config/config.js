export const config = {
	API_KEY: '592a1d7486f32f8ef4d5df86cdf06bf5',
}