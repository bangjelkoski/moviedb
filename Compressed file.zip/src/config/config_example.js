export const config = {
	API_KEY: '',
	BASE_URL: '', // you can also leave blank if you want your application to run in 'root' mode
}