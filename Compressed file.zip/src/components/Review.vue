<template>
  <div class="content">
		 <div class="page-title">
		  	<h2>Reviews!</h2>
		 </div>
	</div>
</template>

<script>
  export default {
    
  }
</script>