<template>
  <div class="content">
		 <div class="page-title">
		  	<h2>404 not found!</h2>
		 </div>
	</div>
</template>

<script>
  export default {
    
  }
</script>