<template>
  <footer>
      <div class="copyright">Copyright &copy; 2017 - <a href="http://abxweb.com" target="_blank">abxweb</a></div>
      <div class="credits">Powered by - <a href="http://themoviedb.org" target="_blank">TheMovieDB</a></div>
  </footer>
</template>

<script>
  export default {

  }
</script>
